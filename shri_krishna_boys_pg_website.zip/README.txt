Shri Krishna Boys PG website
=============================

Free hosting option:
Cloudflare Pages -> https://pages.cloudflare.com/
The site is a static HTML website and can be deployed without paid hosting.

Suggested project name:
shri-krishna-boys-pg

This will normally give a free pages.dev address such as:
https://shri-krishna-boys-pg.pages.dev

Note: the exact subdomain is subject to availability.

Files:
- index.html
- README.txt
